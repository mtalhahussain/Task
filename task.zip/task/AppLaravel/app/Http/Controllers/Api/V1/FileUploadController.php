<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator,Storage;

class FileUploadController extends Controller
{
    public function upload(Request $request)
    {
        
        if ($request->hasFile('file')) {

            $validate = Validator::make($request->all(),[
                'file' => 'required|max:100'
            ]);

            if($validate->fails()) return response()->json(['message' => 'Please upload maximum file size 100kb'], 500);

            $file = $request->file('file');
            $fileName = $file->getClientOriginalName();
            $exists = asset('uploads/'.$fileName);

         
            if (Storage::disk('public')->exists('/uploads' . '/' . $fileName)) {

                Storage::disk('public')->delete('/uploads' . '/' . $fileName);
                $file->move('uploads', $fileName);
              
            }else{
                $file->move('uploads', $fileName);
            }
            
            return response()->json(['message' => 'File uploaded successfully'],201);
        }
        
        return response()->json(['message' => 'No file uploaded'], 400);
    }

    public function download($filename)
    {
        $filePath = public_path('uploads/' . $filename);

        if (file_exists($filePath)) {
            return response()->download($filePath, $filename);
        }

        return response()->json(['message' => 'File not found'], 404);
    }
}
